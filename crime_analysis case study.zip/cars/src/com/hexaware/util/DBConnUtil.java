/* package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnUtil {
    private static Connection connection;

    public static Connection getConnection() throws SQLException {
        String url = DBPropertyUtil.getPropertyString("src/db.properties");
        String username = "root";  // Or retrieve from properties if needed
        String password = "Prethika$29";  // Or retrieve from properties if needed

        if (url == null || url.trim().isEmpty()) {
            throw new SQLException("The URL cannot be null or empty");
        }

        connection = DriverManager.getConnection(url, username, password);
        return connection;
    }
}
*/
/*
package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnUtil {

    public static Connection getConnection() throws SQLException {
        Connection connection = null;
        try {
        	
        	// Load the MySQL JDBC driver
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	
        	//Load connection properties from DBPropertyUtil
            String url = DBPropertyUtil.getPropertyString("db.url");
            String username = DBPropertyUtil.getPropertyString("db.username");
            String password = DBPropertyUtil.getPropertyString("db.password");

            if (url == null || url.isEmpty()) {
                throw new SQLException("The URL cannot be null or empty");
            }

            Class.forName("com.mysql.cj.jdbc.Driver"); // Make sure the driver is loaded
            connection = DriverManager.getConnection(url, username, password);

        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("DB Connection Failed: " + e.getMessage());
            throw e;
        }

        return connection;
    }
}
*/

package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;
// import java.sql.SQLException;

public class DBConnUtil {

	
	public static Connection connection = null;

	public DBConnUtil() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public static Connection getConnection()
	{
		//singleton design pattern
		if (connection == null)
		{
			try
			{
				
				// Load MySQL JDBC driver
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            
				connection = DriverManager.getConnection(
													DBPropertyUtil.get("db.url"),
													DBPropertyUtil.get("db.username"),
													DBPropertyUtil.get("db.password")
						);
				
			}
		catch(Exception  e)
		{
			e.printStackTrace();
		}
		}
		return connection;
	}
	
}