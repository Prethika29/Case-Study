
/*
package com.hexaware.util;

import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {

    public static String getPropertyString(String key) {
        Properties props = new Properties();

        try (InputStream input = DBPropertyUtil.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (input == null) {
                System.out.println("Sorry, unable to find db.properties");
                return null;
            }
            props.load(input);
            return props.getProperty(key);
        } catch (Exception e) {
            System.out.println("Error reading property file: " + e.getMessage());
            return null;
        }
    }
}
*/

package com.hexaware.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class DBPropertyUtil {
	
	//Two static variables created 
	private static final String File_Path ="resources/db.properties";
	private static Properties properties;
	
	static {
		
		// try - catch -- exception handling   
		//try is where your code is which may throw an exception and catch is to catch the exception
		
		try {
			
			// For reading the file 
			FileInputStream fis = new FileInputStream(File_Path);
			properties = new Properties();
			// to load the file which is property file so we are loading with the help of object of Properties class
			properties.load(fis);
			
		}
		catch(IOException e)
		{
			e.printStackTrace();  // jvm 
		}
		
//		String url = properties.getProperty("db.url");
//		String user  =  properties.getProperty("db.username");
//		String pass  =  properties.getProperty("db.password");
//		return url + "|" + user + "|" +pass;

		
		
	}
	
	
		public static String get(String key) {
	
		return properties.getProperty(key);
	}

}