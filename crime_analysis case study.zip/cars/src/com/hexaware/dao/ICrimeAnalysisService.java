package com.hexaware.dao;

import java.util.Collection;
import java.util.Date;

import com.hexaware.entity.Incident;
import com.hexaware.entity.Report;
import com.hexaware.myexceptions.IncidentNumberNotFoundException;

public interface ICrimeAnalysisService {

    // Create a new incident
    boolean createIncident(Incident incident);

    // Update the status of an incident
    boolean updateIncidentStatus(String status, int incidentId);

    // Get a list of incidents within a date range
    Collection<Incident> getIncidentsInDateRange(Date startDate, Date endDate) throws IncidentNumberNotFoundException;

    // Search for incidents based on type
    Collection<Incident> searchIncidents(String incidentType) throws IncidentNumberNotFoundException;

    // Generate a report for an incident
    Report generateIncidentReport(Incident incident);
}
