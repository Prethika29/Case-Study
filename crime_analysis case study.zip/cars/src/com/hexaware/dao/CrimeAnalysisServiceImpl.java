package com.hexaware.dao;

import java.sql.*;
import java.util.*;
import java.util.Date;

import com.hexaware.util.DBConnUtil;
import com.hexaware.entity.Incident;
import com.hexaware.entity.Report;
import com.hexaware.myexceptions.IncidentNumberNotFoundException;

public class CrimeAnalysisServiceImpl implements ICrimeAnalysisService {

    private static Connection connection;

    // Constructor: Assign the DB connection from DBConnUtil
    public CrimeAnalysisServiceImpl() {
        try {
            connection = DBConnUtil.getConnection();
        } catch (Exception e) { // SQLException
            System.out.println("Failed to connect to database: " + e.getMessage());
        }
    }

    // 1. Create a new incident
    @Override
    public boolean createIncident(Incident incident) {
        String sql = "INSERT INTO incident (incidentId, incidentType, incidentDate, location, description, status, victimId, suspectId, officerId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, incident.getIncidentId());
            ps.setString(2, incident.getIncidentType());
            ps.setDate(3, new java.sql.Date(incident.getIncidentDate().getTime()));
            ps.setString(4, incident.getLocation());
            ps.setString(5, incident.getDescription());
            ps.setString(6, incident.getStatus());
            ps.setInt(7, incident.getVictimId());
            ps.setInt(8, incident.getSuspectId());
            ps.setInt(9, incident.getOfficerId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error creating incident: " + e.getMessage());
            return false;
        }
    }

    // 2. Update the status of an incident
    @Override
    public boolean updateIncidentStatus(String status, int incidentId) {
        String sql = "UPDATE incident SET status = ? WHERE incidentId = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, incidentId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error updating incident status: " + e.getMessage());
            return false;
        }
    }

    // 3. Get a list of incidents within a date range
    @Override
    public Collection<Incident> getIncidentsInDateRange(Date startDate, Date endDate) throws IncidentNumberNotFoundException {
        List<Incident> incidents = new ArrayList<>();
        String sql = "SELECT * FROM incident WHERE incidentDate BETWEEN ? AND ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setDate(1, new java.sql.Date(startDate.getTime()));
            ps.setDate(2, new java.sql.Date(endDate.getTime()));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                incidents.add(mapIncident(rs));
            }
            if (incidents.isEmpty()) {
                throw new IncidentNumberNotFoundException("No incidents found in the given date range.");
            }
        } catch (SQLException e) {
            System.out.println("Error fetching incidents in date range: " + e.getMessage());
        }
        return incidents;
    }

    // 4. Search for incidents based on incidentType
    @Override
    public Collection<Incident> searchIncidents(String incidentType) throws IncidentNumberNotFoundException {
        List<Incident> incidents = new ArrayList<>();
        String sql = "SELECT * FROM incident WHERE incidentType = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, incidentType);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                incidents.add(mapIncident(rs));
            }
            if (incidents.isEmpty()) {
                throw new IncidentNumberNotFoundException("No incidents found for the given type: " + incidentType);
            }
        } catch (SQLException e) {
            System.out.println("Error searching incidents: " + e.getMessage());
        }
        return incidents;
    }

    // 5. Generate incident report
    @Override
    public Report generateIncidentReport(Incident incident) {
        String sql = "SELECT * FROM report WHERE incidentId = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, incident.getIncidentId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Report report = new Report();
                report.setReportId(rs.getInt("reportId"));
                report.setIncidentId(rs.getInt("incidentId"));
                report.setReportingOfficer(rs.getInt("reportingOfficer"));
                report.setReportDate(rs.getDate("reportDate"));
                report.setReportDetails(rs.getString("reportDetails"));
                report.setStatus(rs.getString("status"));
                return report;
            }
        } catch (SQLException e) {
            System.out.println("Error generating report: " + e.getMessage());
        }
        return null;
    }

    // Helper method to map ResultSet to Incident object
    private Incident mapIncident(ResultSet rs) throws SQLException {
        Incident incident = new Incident();
        incident.setIncidentId(rs.getInt("incidentId"));
        incident.setIncidentType(rs.getString("incidentType"));
        incident.setIncidentDate(rs.getDate("incidentDate"));
        incident.setLocation(rs.getString("location"));
        incident.setDescription(rs.getString("description"));
        incident.setStatus(rs.getString("status"));
        incident.setVictimId(rs.getInt("victimId"));
        incident.setSuspectId(rs.getInt("suspectId"));
        incident.setOfficerId(rs.getInt("officerId"));
        return incident;
    }
}
