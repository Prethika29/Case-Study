package com.hexaware.main;

import com.hexaware.dao.CrimeAnalysisServiceImpl;
import com.hexaware.dao.ICrimeAnalysisService;
import com.hexaware.entity.Incident;
import com.hexaware.entity.Report;
import com.hexaware.myexceptions.IncidentNumberNotFoundException;

import java.text.SimpleDateFormat;
import java.util.*;

public class MainModule {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ICrimeAnalysisService service = new CrimeAnalysisServiceImpl();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        while (true) {
            System.out.println("\n===== Crime Analysis & Reporting System =====");
            System.out.println("1. Create New Incident");
            System.out.println("2. Update Incident Status");
            System.out.println("3. Get Incidents by Date Range");
            System.out.println("4. Search Incidents by Type");
            System.out.println("5. Generate Report");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");

            try {
                int choice = Integer.parseInt(sc.nextLine());

                switch (choice) {
                    case 1:
                        System.out.print("Incident ID: ");
                        int incidentId = Integer.parseInt(sc.nextLine());

                        System.out.print("Incident Type: ");
                        String type = sc.nextLine();

                        System.out.print("Incident Date (yyyy-MM-dd): ");
                        Date date = sdf.parse(sc.nextLine());

                        System.out.print("Location: ");
                        String location = sc.nextLine();

                        System.out.print("Description: ");
                        String description = sc.nextLine();

                        System.out.print("Status: ");
                        String status = sc.nextLine();

                        System.out.print("Victim ID: ");
                        int victimId = Integer.parseInt(sc.nextLine());

                        System.out.print("Suspect ID: ");
                        int suspectId = Integer.parseInt(sc.nextLine());

                        System.out.print("Officer ID: ");
                        int officerId = Integer.parseInt(sc.nextLine());

                        Incident newIncident = new Incident(incidentId, type, date, location, description, status, victimId, suspectId, officerId);
                        boolean created = service.createIncident(newIncident);
                        System.out.println(created ? "Incident created successfully." : "Failed to create incident.");
                        break;

                    case 2:
                        System.out.print("Incident ID: ");
                        int updateId = Integer.parseInt(sc.nextLine());

                        System.out.print("New Status: ");
                        String newStatus = sc.nextLine();

                        boolean updated = service.updateIncidentStatus(newStatus, updateId);
                        if (!updated) {
                            throw new IncidentNumberNotFoundException("Incident ID not found.");
                        }
                        System.out.println("Incident status updated.");
                        break;

                    case 3:
                        System.out.print("Start Date (yyyy-MM-dd): ");
                        Date start = sdf.parse(sc.nextLine());

                        System.out.print("End Date (yyyy-MM-dd): ");
                        Date end = sdf.parse(sc.nextLine());

                        Collection<Incident> dateIncidents = service.getIncidentsInDateRange(start, end);
                        if (dateIncidents.isEmpty()) {
                            throw new IncidentNumberNotFoundException("No incidents found in the given date range.");
                        }
                        dateIncidents.forEach(System.out::println);
                        break;

                    case 4:
                        System.out.print("Incident Type: ");
                        String searchType = sc.nextLine();

                        Collection<Incident> typeIncidents = service.searchIncidents(searchType);
                        if (typeIncidents.isEmpty()) {
                            throw new IncidentNumberNotFoundException("No incidents found for the given type.");
                        }
                        typeIncidents.forEach(System.out::println);
                        break;

                    case 5:
                        System.out.print("Incident ID: ");
                        int reportIncidentId = Integer.parseInt(sc.nextLine());

                        Incident reportIncident = new Incident();
                        reportIncident.setIncidentId(reportIncidentId);

                        Report report = service.generateIncidentReport(reportIncident);
                        if (report == null) {
                            throw new IncidentNumberNotFoundException("No report found for the given Incident ID.");
                        }
                        System.out.println(report);
                        break;

                    case 6:
                        System.out.println("Exiting system. Goodbye!");
                        sc.close();
                        System.exit(0);

                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (IncidentNumberNotFoundException ex) {
                System.out.println("Custom Error: " + ex.getMessage());
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
