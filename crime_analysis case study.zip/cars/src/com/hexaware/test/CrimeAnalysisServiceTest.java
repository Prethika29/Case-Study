package com.hexaware.test;

import org.junit.jupiter.api.Test;

import com.hexaware.dao.CrimeAnalysisServiceImpl;
import com.hexaware.entity.Incident;
import org.junit.jupiter.api.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class CrimeAnalysisServiceImplTest {

    private static CrimeAnalysisServiceImpl service;
    private static SimpleDateFormat sdf;

    @BeforeAll
    static void setup() {
        service = new CrimeAnalysisServiceImpl();
        sdf = new SimpleDateFormat("yyyy-MM-dd");
    }

    @Test
    void testCreateIncident() throws Exception {
        Date date = sdf.parse("2025-05-12");
        Incident incident = new Incident(
                9999, "Test Type", date, "Test Location", "Test Description", "Open",
                1, 1, 1
        );

        boolean result = service.createIncident(incident);
        assertTrue(result, "Incident should be created successfully.");
    }

    @Test
    void testUpdateIncidentStatus_Valid() {
        String newStatus = "Closed";
        int existingIncidentId = 9999; // Make sure this ID exists in DB or was created in create test

        boolean result = service.updateIncidentStatus(newStatus, existingIncidentId);
        assertTrue(result, "Status should be updated for existing incident.");
    }

    @Test
    void testUpdateIncidentStatus_InvalidId() {
        String newStatus = "Closed";
        int nonExistentId = -1;

        boolean result = service.updateIncidentStatus(newStatus, nonExistentId);
        assertFalse(result, "Status update should fail for non-existing incident.");
    }
}
